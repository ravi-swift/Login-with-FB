//
//  ViewController.swift
//  LoginwithFB
//
//  Created by Rp on 03/12/18.
//  Copyright © 2018 Rp. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func clickOnFb(){
        
        let manager = FBSDKLoginManager()
        manager.loginBehavior = .web
        
        manager.logIn(withReadPermissions: ["email"], from: self) { (result, err) in
            let request = FBSDKGraphRequest.init(graphPath: "/me", parameters: ["fields":"id,email,first_name,last_name,gender,name"])
            
            request?.start(completionHandler: { (connection, result, err) in
                print(result)
                print(err)
            })
            
        }
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

